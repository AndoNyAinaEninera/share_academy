import sqlite3
import matplotlib.pyplot as plt


# connect to database
connection = sqlite3.connect('data_analysis.db')
cursor = connection.cursor()

# retrieve data
cursor.execute('SELECT Product, (Price*Quantity) AS TotalRevenue FROM Sales;')
data = cursor.fetchall()

# create vizualisation
# Prepare data for visualization 
Product = [row[0] for row in data] 
TotalRevenue = [row[1] for row in data] 

# Create bar chart 
plt.bar(Product, TotalRevenue, color="skyblue") 
plt.xlabel("Product") 
plt.ylabel("Total Revenue") 
plt.title("Total Revenue by Product") 
plt.xticks(rotation=90, fontsize=8) 
plt.tight_layout()
plt.savefig("revenue_chart.png") 
plt.show() 
connection.close()