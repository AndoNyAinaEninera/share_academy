# create a function to calculate revenue that take 2 variables and multiply them
def calculate_revenue(price, quantity): 
    return price * quantity

# storing price and quantity in 2 list
pricelist = [12, 30, 90, 2]
quantitylist = [2, 3, 20, 45]


# loop throught the 2 lists and print the revenue of each product by using calculate_revenue function
for (i, j) in zip(pricelist, quantitylist):
    print ('revenue =', i, '*', j, '=', calculate_revenue(i, j))