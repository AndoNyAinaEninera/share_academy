# setting 2 dictionaries to store product price and product sellings
pricesdict = {
  "iphone": 1300,
  "samsung": 290,
  "dell": 1964,
  "asus": 2020
}

sellingsdict = {
    "iphone": 20,
    "samsung": 29,
    "dell": 19,
    "asus": 220
}


# create a function to calculate revenue price*selling
def calculate_revenue (price, selling):
    return (price * selling)


# loop throught the 2 dict to fetch name, price and sellings and print the calculated revenue
for (i, j) in zip (pricesdict, sellingsdict) :
    print ("The revenue of", i, "sellings is" , calculate_revenue(pricesdict[i], sellingsdict[j]))