
# create a list of product and print each
list = ["apple", "banana", "cherry", "pineapple", "orange"]

for i in list :
    print (i)