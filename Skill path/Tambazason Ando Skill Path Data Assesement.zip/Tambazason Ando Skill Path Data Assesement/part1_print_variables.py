print('Hello, Data World!')

# setting 2 variables
price = 20
quantity = 20

# calculating and printing the total of the 2 variables
total = price + quantity
print ("Total =", total)