-- • Retrieve all data from the Sales table.
SELECT * FROM Sales;

-- • Calculate the total revenue for each product (Price × Quantity).
SELECT (Price*Quantity) AS TotalRevenue FROM Sales;
 
-- • Find the product with the highest price.
SELECT Product, MAX(Price) AS MaxPrice FROM Sales;

-- • Retrieve all orders placed on a specific date.
SELECT Product AS "Ordered in 02/12/23" FROM Sales  WHERE OrderDate="02/12/23";
