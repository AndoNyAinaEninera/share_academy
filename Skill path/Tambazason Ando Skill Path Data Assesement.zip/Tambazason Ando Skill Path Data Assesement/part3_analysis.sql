-- • Calculate the total revenue for all products (sum of Price × Quantity).
SELECT (SUM(Price*Quantity)) AS TotalRevenue FROM Sales;




-- • Identify the most popular product (product with the highest Quantity sold).
SELECT 
    Product,                           -- Select the Product name
    SUM(Quantity) AS TotalQuantitySold -- Calculate the total quantity sold for each product
FROM 
    Sales                               -- From the table (replace 'Sales' with the actual table name)
GROUP BY 
    Product                              -- Group the results by product to calculate the total quantity sold per product
ORDER BY 
    TotalQuantitySold DESC              -- Sort the results in descending order to get the product with the highest total quantity sold first
LIMIT 1;                                -- Only return the top product (most popular)




-- • Calculate the average order value (total revenue divided by the total number of orders).
SELECT (SUM(Price*Quantity))/COUNT(*) AS AverageOrderValue FROM Sales;

-- • Find the total number of unique products in the dataset.
SELECT COUNT(DISTINCT Product) AS TotalNumberOfUniqueProduct FROM Sales;





-- • Determine the product with the highest revenue.
SELECT 
    Product,                            -- Select the Product name
    SUM(Price * Quantity) AS Revenue    -- Calculate the total revenue by multiplying price and quantity for each product
FROM 
    Sales                               -- From the 'Sales' table (replace with the actual table name if different)
GROUP BY 
    Product                             -- Group the data by Product to calculate the total revenue for each product
ORDER BY 
    Revenue DESC                        -- Order the results by Revenue in descending order to get the highest revenue first
LIMIT 1;                                -- Limit the result to only the product with the highest revenue
